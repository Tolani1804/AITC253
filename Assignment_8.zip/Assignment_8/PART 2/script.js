function submitEntry() {
    const author = document.getElementById('author').value;
    const blogEntry = document.getElementById('blogEntry').value;
    
    if (author && blogEntry) {
        const timestamp = new Date().toLocaleString();

        // To Create a new blog entry div
        const entryDiv = document.createElement('div');
        entryDiv.classList.add('entry');
        
        // To Display author, blog entry, and timestamp
        entryDiv.innerHTML = `<p>${blogEntry}</p><p class="author">- ${author}</p><p class="timestamp">${timestamp}</p>`;

        // To Append the new entry to the entries div
        document.getElementById('entries').appendChild(entryDiv);

        // To Clear the form
        document.getElementById('author').value = '';
        document.getElementById('blogEntry').value = '';
    } else {
        alert('Please enter author and blog entry.');
    }
}